-- phpMyAdmin SQL Dump
-- version 4.6.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: 17-Out-2017 às 01:32
-- Versão do servidor: 5.7.14
-- PHP Version: 5.6.25

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `caixa_eletronico`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `contas`
--

CREATE TABLE `contas` (
  `id` int(10) NOT NULL,
  `nome_titular` varchar(150) NOT NULL,
  `agencia` int(10) NOT NULL,
  `conta` int(10) NOT NULL,
  `senha` varchar(32) NOT NULL,
  `saldo` double NOT NULL,
  `ativa` int(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `contas`
--

INSERT INTO `contas` (`id`, `nome_titular`, `agencia`, `conta`, `senha`, `saldo`, `ativa`) VALUES
(1, 'Thulio Guirelle Horta', 860, 123, '81dc9bdb52d04dc20036dbd8313ed055', 97, 0),
(2, 'Vitor Guirelle Horta', 860, 321, '81dc9bdb52d04dc20036dbd8313ed055', 824, 0);

-- --------------------------------------------------------

--
-- Estrutura da tabela `extrato`
--

CREATE TABLE `extrato` (
  `id` int(10) NOT NULL,
  `agencia` int(11) NOT NULL,
  `conta` int(11) NOT NULL,
  `valor` double NOT NULL,
  `operacao` int(1) NOT NULL,
  `data_operacao` datetime NOT NULL,
  `saldo` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `extrato`
--

INSERT INTO `extrato` (`id`, `agencia`, `conta`, `valor`, `operacao`, `data_operacao`, `saldo`) VALUES
(1, 860, 123, 200, 1, '2017-10-13 04:22:10', 200),
(2, 860, 123, 150, 2, '2017-10-13 07:29:36', 50),
(3, 860, 123, 30, 2, '2017-10-14 01:54:00', 20),
(4, 860, 123, 17, 2, '2017-10-14 01:55:27', 13),
(5, 860, 123, 100, 1, '2017-10-14 02:09:11', 113),
(6, 860, 123, 50, 2, '2017-10-14 02:10:34', 63),
(7, 860, 123, 37, 1, '2017-10-14 02:10:55', 100),
(8, 860, 321, 1000, 1, '2017-10-14 02:12:44', 1000),
(9, 860, 321, 257.39, 2, '2017-10-14 02:13:23', 742.61),
(10, 860, 321, 19.5, 2, '2017-10-14 02:15:42', 723.11),
(11, 860, 321, 100.89, 1, '2017-10-14 02:15:59', 824),
(12, 860, 123, 1, 2, '2017-10-16 00:32:17', 99),
(13, 860, 123, 2, 2, '2017-10-16 00:34:57', 97),
(14, 860, 123, 1, 2, '2017-10-16 00:34:59', 96),
(15, 860, 123, 2, 2, '2017-10-16 00:35:03', 94),
(16, 860, 123, 1, 1, '2017-10-16 00:35:10', 95),
(17, 860, 123, 2, 1, '2017-10-16 00:35:13', 97);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `contas`
--
ALTER TABLE `contas`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `extrato`
--
ALTER TABLE `extrato`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `contas`
--
ALTER TABLE `contas`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `extrato`
--
ALTER TABLE `extrato`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
